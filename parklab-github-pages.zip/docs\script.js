const menu = document.getElementById('menu');
const panel = document.getElementById('navigation');
if (menu && panel) {
  const closeMenu = () => { panel.classList.remove('is-open'); menu.setAttribute('aria-expanded', 'false'); };
  menu.addEventListener('click', () => {
    const open = panel.classList.toggle('is-open');
    menu.setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && panel.classList.contains('is-open')) { closeMenu(); menu.focus(); }
  });
  window.matchMedia('(max-width: 768px)').addEventListener('change', closeMenu);
}
